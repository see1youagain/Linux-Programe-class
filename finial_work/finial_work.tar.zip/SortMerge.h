#ifndef SORTMERGE_H
#define SORTMERGE_H

#include <vector>
#include <string>

void mergeFiles(const std::vector<std::string> &filePaths, const std::string &outputPath);

#endif // SORTMERGE_H
